package main

import (
	"strings"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/protos/peer"
)

type helloWorld struct {
}

func main() {
	shim.Start(new(helloWorld))
}

func (cc *helloWorld) Init(stub shim.ChaincodeStubInterface) peer.Response {
	return shim.Success(nil)
}

func (cc *helloWorld) Invoke(stub shim.ChaincodeStubInterface) peer.Response {
	function, args := stub.GetFunctionAndParameters()
	switch function {
	case "read":
		return read(stub, args)
	case "write":
		return write(stub, args)
	default:
		return shim.Error("valid methods are read and write")
	}
}

func read(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) != 1 {
		return shim.Error("Invalid parameters")

	}

	id := strings.ToLower(args[0])

	value, err := stub.GetState(id)

	if value != nil && err == nil {
		return shim.Success(value)

	} else {
		return shim.Error("Not found")
	}

}

func write(stub shim.ChaincodeStubInterface, args []string) peer.Response {
	if len(args) < 2 || len(args[0]) < 3 || len(args[1]) < 1 {
		return shim.Error("Parameter not passed properly")

	} else {

		id := strings.ToLower(args[0])
		txt := args[1]

		err := stub.PutState(id, []byte(txt))
		if err != nil {
			return shim.Error(err.Error())

		}

		return shim.Success(nil)

	}
}
